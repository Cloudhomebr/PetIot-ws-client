# PetIot-ws-client
Aplicativo HTML5 do PetIot - Casa conectada
